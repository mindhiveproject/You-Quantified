
Hi! I'm a small file meant to describe the contents of your folder. 

You: Quantified saves the data recorded from each of your devices as separate "csv" files. There is an additional file with the metadata for each device.

The data gathered from the web browser can have unreliable time synchrony or sampling rates, so be aware of its usage for research purposes. 

If you have questions or suggestions, please visit the repository at https://github.com/esromerog/You-Quantified.

This folder contains the following files: epocx-9a582932.csv, metadata.csv